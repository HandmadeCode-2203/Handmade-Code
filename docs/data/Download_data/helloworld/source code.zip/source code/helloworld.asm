;windowsx64
extern MessageBoxA : proc
extern ExitProcess : proc

.data
    msgTitle db "Helloworld GUI", 0
    msgText db "Hello world", 0ah, 0
.code

main proc
    sub rsp, 40
    mov rcx, 0
    lea rdx, msgText
    lea r8, msgTitle
    mov r9, 0
    call MessageBoxA
    add rsp, 40
    mov rcx, 0
    call ExitProcess
main endp
end