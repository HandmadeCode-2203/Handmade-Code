@echo off
ml64 /c helloworld.asm
link helloworld.obj /subsystem:windows /entry:main /defaultlib:user32.lib /defaultlib:kernel32.lib /out:hello_world_sample.exe
echo Build succesfull: helloworldsample.exe
pause